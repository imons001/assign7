/**
 * Collection of Polyhedra and all associated read/write utilities.
 */
package polyhedra;
